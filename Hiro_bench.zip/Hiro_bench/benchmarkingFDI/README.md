# FDI Benchmark Problems

Empirical codes for benchmarking model-based, data-driven, and hybrid FDI

In Hiro3, run main_H (the main code to run). 
